void button(int x, int y, int width, int height, char text[]);
void button_clicked(int x, int y, int width, int height, char text[]);
void background_brick(int x, int y);
void foreground_brick(int x, int y);
void background(int x, int y);
void foreground(int x, int y);
void torch(int x, int y);
void display_text(int x, int y, char input[10]);
void input_box(int x, int y, int width, int height, char input[10], int *redo);